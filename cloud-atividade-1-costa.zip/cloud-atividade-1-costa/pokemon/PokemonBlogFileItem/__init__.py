from azure.cosmos.aio import CosmosClient as cosmos_client
from azure.cosmos import PartitionKey, exceptions
import asyncio
import logging
import json
import urllib.request
import requests
import uuid

import azure.functions as func

# <add_uri_and_key>
endpoint = "https:///"
key = "=="
# </add_uri_and_key>

pokemonData = {}

# <define_database_and_container_name>
database_name = 'PokemonDataFiterDb'
container_name = 'pokemonList'


async def get_or_create_db(client, database_name):
    try:
        database_obj = client.get_database_client(database_name)
        await database_obj.read()
        return database_obj
    except exceptions.CosmosResourceNotFoundError:
        print("Creating database")
        return await client.create_database(database_name)

async def get_or_create_container(database_obj, container_name):
    try:
        todo_items_container = database_obj.get_container_client(
            container_name)
        await todo_items_container.read()
        return todo_items_container
    except exceptions.CosmosResourceNotFoundError:
        print("Creating container with id as partition key")
        return await database_obj.create_container(
            id=container_name,
            partition_key=PartitionKey(path="/name"))
  
    except exceptions.CosmosHttpResponseError:
        raise

async def populate_container_items(container_obj, items_to_create):
    # Add items to the container
    inserted_item = await container_obj.create_item(body=items_to_create)
    print(inserted_item['id'])


async def run_sample():
    
    async with cosmos_client(endpoint, credential=key) as client:
        
        try:
            # create a database
            database_obj = await get_or_create_db(client, database_name)
            # create a container
            container_obj = await get_or_create_container(database_obj, container_name)
            # populate pokemon item
            await populate_container_items(container_obj, pokemonData)
        except exceptions.CosmosHttpResponseError as e:
            print('\nrun_sample has caught an error. {0}'.format(e.message))
        finally:
            print("\nQuickstart complete")
# </run_sample>

def main(myblob: func.InputStream):

    url = myblob.name
    # retrieving data from URL
    webUrl = urllib.request.urlopen(url)
    print("Result code: " + str(webUrl.getcode()))

# print data from URL
    print("Returned data: -----------------")
    file = webUrl.read().decode("utf-8")

    next_line = file.split('\r\n')

    i = 0
    for line in next_line:
        if not line:
            break
        else:
            i = i+1
            responseContent = requests.get(line)

            filterPokemonData = {}
            # Opening JSON file
            gson = json.loads(responseContent.content)

            filterPokemonData["id"] = str(gson["id"]) + str(uuid.uuid4())
            filterPokemonData["name"] = gson["name"]
            filterPokemonData["types"] = gson["types"]
            filterPokemonData["height"] = gson["height"]
            filterPokemonData["weight"] = gson["weight"]
            filterPokemonData["moves"] = gson["moves"]

            pokemonData["id"] =gson["name"]+ str(uuid.uuid4())
            pokemonData["name"] =gson["name"]
            pokemonData["content"] = filterPokemonData

            loop = asyncio.get_event_loop()
            loop.run_until_complete(run_sample())






